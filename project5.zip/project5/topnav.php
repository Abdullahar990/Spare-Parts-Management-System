<div class="dashboard_topNav">
    <a href="" id="toggleBtn"><i class="fa fa-navicon"></i></a>
    <a href="logout.php" id="logoutBtn"><i class="fa fa-power-off"></i> Log out</a>
</div>